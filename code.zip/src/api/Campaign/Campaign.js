import invoke from "../../utils/invoke";

export const AddCompaignPost = async (user) => {
  const { data } = await invoke({
    url: `/api/Compaign`,
    method: "POST",
    data: user,
    headers: {
      "Content-Type": "multipart/form-data",
    },
  });
  return data;
};

// export const AddCompaignPost = async (campaign) => {
//   const formData = new FormData();

//   // Append all campaign fields
//   Object.keys(campaign).forEach((key) => {
//     if (key === "uploadImages") {
//       campaign.uploadImages.forEach((file) => {
//         formData.append("uploadImages", file); // multiple files allowed
//       });
//     } else {
//       formData.append(key, campaign[key]);
//     }
//   });

//   const { data } = await invoke({
//     url: `/api/Compaign`,
//     method: "POST",
//     data: formData,
//     headers: {
//       "Content-Type": "multipart/form-data",
//     },
//   });

//   return data;
// };
